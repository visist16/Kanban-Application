from flask.helpers import flash
from flask.templating import render_template
from flask_restful import Resource, Api
from flask_restful import fields, marshal_with
from flask_restful import reqparse
from .models import User, List, Card
from . import db
from flask import current_app as app
import werkzeug
from flask import abort, redirect, url_for
import random

user_post_args = reqparse.RequestParser()
user_post_args.add_argument('username', location='form')
user_post_args.add_argument('password', location='form')

list_post_args = reqparse.RequestParser()
list_post_args.add_argument('list_name', location='form')
list_post_args.add_argument('description', location='form')

card_post_args = reqparse.RequestParser()
card_post_args.add_argument('list', location='form')
card_post_args.add_argument('title', location='form')
card_post_args.add_argument('content', location='form')
card_post_args.add_argument('deadline', location='form')
card_post_args.add_argument('is_completed_flag', location='form')


# User APIs
class UserAPI(Resource):
    # api for registration/sign-up form (register.html)
    def post(self):
        args = user_post_args.parse_args()
        user_check = User.query.filter_by(username=args['username']).first()
        if user_check:
            flash('Username is already in use', category='error')
            return redirect('/register')             
        new_user = User(username=args['username'], password = args['password'])
        try:
            db.session.add(new_user)
            db.session.commit()
            return redirect('/login')
        except:
            return redirect('/register')

# List APIs
class ListAPI(Resource):
    # Used in dashboard for showing lists of a user
    def get(self, username):
        lists = List.query.filter_by(user=username).all()
        r=[]
        for list in lists:
            cards = Card.query.filter_by(clist=list.list_name).all()
            cards_list=[]
            for card in cards:
                cards_list.append({'card_id': card.card_id, 'title':card.title, "content":card.content, "deadline":card.deadline, "is_completed_flag":card.is_completed_flag})

            r.append({'list_id': list.list_id, 'list_name':list.list_name, 'description':list.description, 'cards':cards_list })
        output = {'lists': r}
        return output

    # used for adding lists in dashboard of a user
    def post(self, user):
        args = list_post_args.parse_args()
        current_lists = List.query.filter_by(user=user)
        lists=[]
        for list in current_lists:
            lists.append(list.list_name)
        new_list_name=args['list_name']
        new_list_content=args['description']
        if args['list_name'] in lists:
            list_to_delete= List.query.filter_by(list_name=args['list_name'], user=user).first()
            db.session.delete(list_to_delete)   
        list_to_add= List(list_name=new_list_name, description=new_list_content, user=user)
        db.session.add(list_to_add)
        db.session.commit()
        return redirect('/dashboard')

# Card APIs
class CardAPI(Resource):

# adding a card to a list
    def post(self, user, list):
        args = card_post_args.parse_args()
        if args['is_completed_flag']=="on":
            is_completed_flag=True
        else:
            is_completed_flag=False
        new_card = Card(clist=args['list'], title = args['title'], content = args['content'], deadline = args['deadline'], is_completed_flag = is_completed_flag)
        db.session.add(new_card)
        db.session.commit()
        return redirect('/dashboard')



        
