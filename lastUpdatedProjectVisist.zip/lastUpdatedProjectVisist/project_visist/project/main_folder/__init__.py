from flask import Flask
from flask_sqlalchemy import SQLAlchemy

from flask_login import LoginManager, login_manager
from flask_restful import Api
from os import path

#-------------initialization-------------------
db = SQLAlchemy()
data_base= "final_project.sqlite3"

#---------------creating app ------------------
def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'visist'
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{data_base}'
    db.init_app(app)
    api = Api(app)

#-----------------adding api resources----------------
    from .api import UserAPI, ListAPI, CardAPI
    api.add_resource(UserAPI, '/api/user', '/api/user/<string:username>')   
    api.add_resource(ListAPI, '/api/<string:user>/addlist', "/api/list/<string:username>", "/api/<string:username>/list/<string:list_name>/edit","/api/<string:username>/list/<int:list_id>/delete" )
    api.add_resource(CardAPI, '/api/<string:user>/<string:list>/addcard', '/api/card/<int:card_id>/edit', '/api/card/<int:card_id>/delete')

#------------- creating view blue prints--------------
    from .controllers import views
    app.register_blueprint(views, url_prefix="/")

#---------------importing models(tabels)-------------
    from .models import User, List, Card

#---------------creating db--------------------------
    create_db(app)

#-----------------login manager--------------
    login_manager = LoginManager()
    login_manager.login_view = "views.login"
    login_manager.init_app(app)
    @login_manager.user_loader
    def load_user(id):
        return User.query.get(int(id))

#---------------- returnind app, api----------------
    return  app, api


#-----------------------creating db function-----------
def create_db(app):
    if not path.exists("main_folder/"+ data_base):
        db.create_all(app=app)
    print('DATABASE ALREADY EXISTS')