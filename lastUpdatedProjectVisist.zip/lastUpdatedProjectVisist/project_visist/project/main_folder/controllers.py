#from re import S
from flask import Blueprint, render_template, request, flash
from flask_login import login_user, logout_user, current_user
from flask_login.utils import login_required
from werkzeug.utils import redirect
from .models import User, List, Card
from . import db
import requests
from datetime import datetime
import matplotlib.pyplot as plt

views= Blueprint("views", __name__)

# landing page/home page
@views.route('/', methods=['GET'])
def home_page():
    return render_template('home_page.html')

# login page
@views.route('/login', methods = ['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get("username")
        password = request.form.get("password")

        user = User.query.filter_by(username=username).first()
        if user:
            if user.password==password:
                login_user(user, remember=True)
                return redirect('/dashboard')
            else:
                flash('Please type the right password.', category='error')
        else:
            flash('No user, with that username', category='error')

    return render_template('login.html')

# logout
@views.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/')

# link for sign-up/register page
@views.route('/register', methods = ['GET', 'POST'])
def register():
    return render_template('register.html')

# dashboard
@views.route('/dashboard', methods = ['GET', 'POST'])
@login_required
def dashboard():
    list_info= requests.get(f'http://127.0.0.1:5000/api/list/{current_user.username}')
    list_info=list_info.json()
    return render_template('dashboard.html', lists=list_info['lists'], user=current_user.username)

# add a list
@views.route('/add_list', methods = ['GET'])
@login_required
def add_list():
    return render_template('add_list.html', user=current_user.username)

# edit the list
@views.route('<string:user>/list/<string:list_name>/edit', methods=['GET', 'POST', 'PUT', 'PATCH'])
def editList(list_name, user):
    data= List.query.filter_by(list_name=list_name, user=user).first()
    if data:
        return render_template('add_list.html',list_name=data.list_name, description=data.description, user=current_user.username, data=True)

# delete a list based on list name
@views.route('/<string:user>/list/<string:list>/delete', methods=['GET','POST'])
def deletelist(list, user):
    list_to_delete= List.query.filter_by(list_name=list, user=user).first()
    db.session.delete(list_to_delete)
    db.session.commit()
    return redirect('/dashboard')

# delete the list based on list id
@views.route('<string:user>/list/<int:list_id>/delete', methods=['GET'])
def deleteList(list_id, user):
    list_to_delete= List.query.filter_by(list_id=list_id, user=user).first()
    db.session.delete(list_to_delete)
    db.session.commit()
    return redirect('/dashboard')  

# add a card
@views.route('/add_card/<string:list>', methods = ['GET'])
@login_required
def add_card(list):
    data=requests.get(f'http://127.0.0.1:5000/api/list/{current_user.username}')
    data=data.json()
    lists = []
    for l in data['lists']:
        lists.append(l['list_name'])
    return render_template('add_card.html', user=current_user.username, list=list, lists=lists)

# delete the card
@views.route('/card/<int:card_id>/delete', methods=['GET', 'POST', 'DELETE'])
def deletecard(card_id):
    card_to_delete= Card.query.filter_by(card_id=card_id).first()
    db.session.delete(card_to_delete)
    db.session.commit()
    return redirect('/dashboard')

# edit the card
@views.route('/card/<int:card_id>/edit', methods=['GET', 'POST', 'PUT', 'PATCH'])
def editCard(card_id):
    data= Card.query.filter_by(card_id=card_id).first()
    listData=requests.get(f'http://127.0.0.1:5000/api/list/{current_user.username}')
    listData=listData.json()
    lists = []
    for l in listData['lists']:
        lists.append(l['list_name'])
    if data:
        if data.is_completed_flag=="True":
            is_completed_flag= "on"
        else:
            is_completed_flag="off"
        return render_template('add_card.html', list=data.clist, title=data.title, content=data.content, deadline=data.deadline, is_completed_flag=is_completed_flag, lists=lists, user=current_user.username, data=True)

# summary page
@views.route('/summary', methods = ['GET'])
@login_required
def summary():
    list_info= requests.get(f'http://127.0.0.1:5000/api/list/{current_user.username}')
    list_info=list_info.json()
    list_stats = []
    for l in list_info['lists']:
        cards = l['cards']
        completed = {}
        crossedDeadline= {}
        stillPending= {}
        for c in cards:
            if c['is_completed_flag'] == True:
                if c['deadline'] in completed:
                    completed[c['deadline']] = completed[c['deadline']] + 1
                else:
                    completed[c['deadline']] = 1    
            else:
                if datetime.today() > datetime.strptime(c['deadline'], "%Y-%m-%d"):
                    if c['deadline'] in crossedDeadline:
                        crossedDeadline[c['deadline']] = crossedDeadline[c['deadline']] + 1
                    else:
                        crossedDeadline[c['deadline']] = 1 
                else:
                    if c['deadline'] in stillPending:
                        stillPending[c['deadline']] = stillPending[c['deadline']] + 1
                    else:
                        stillPending[c['deadline']] = 1
        list_stats.append({ 'name': l['list_name'], 'completed': completed, 'crossedDeadline': crossedDeadline, 'stillPending': stillPending })

    for list_info in list_stats:
        dates = []
        tasks = []
        for data in list_info['completed']:
            dates.append(data)
            tasks.append(list_info['completed'][data])
        plt.switch_backend('Agg') 
        plt.bar(dates, tasks, color = 'g', label = 'Completed Tasks')
    
        plt.xlabel('Completed Date', fontsize = 12)
        plt.ylabel('Task Count', fontsize = 12)
    
        plt.title('Completed Task Count', fontsize = 20)
        plt.legend()
        plt.show()
        plt.plot()
        filename = list_info['name'] + '_completed'
        plt.savefig(f'./project_visist/project/main_folder/static/images/{filename}.png')

    for list_info in list_stats:
        dates = []
        tasks = []
        for data in list_info['crossedDeadline']:
            dates.append(data)
            tasks.append(list_info['crossedDeadline'][data])
        plt.switch_backend('Agg') 
        plt.bar(dates, tasks, color = 'r', label = 'Tasks that crossed deadline')
    
        plt.xlabel('Deadline Date', fontsize = 12)
        plt.ylabel('Task Count', fontsize = 12)
    
        plt.title('Deadline crossed Task Count', fontsize = 20)
        plt.legend()
        plt.show()
        plt.plot()
        filename = list_info['name'] + '_deadline'
        plt.savefig(f'./project_visist/project/main_folder/static/images/{filename}.png')

    for list_info in list_stats:
        dates = []
        tasks = []
        for data in list_info['stillPending']:
            dates.append(data)
            tasks.append(list_info['stillPending'][data])
        plt.switch_backend('Agg') 
        plt.bar(dates, tasks, color = 'b', label = 'Still Pending Tasks')
    
        plt.xlabel('Deadline Date', fontsize = 12)
        plt.ylabel('Task Count', fontsize = 12)
    
        plt.title('Still Pending Task Count', fontsize = 20)
        plt.legend()
        plt.show()
        plt.plot()
        filename = list_info['name'] + '_pending'
        plt.savefig(f'./project_visist/project/main_folder/static/images/{filename}.png')        
    print(list_stats)

    return render_template('summary.html', list_stats=list_stats, user=current_user.username)