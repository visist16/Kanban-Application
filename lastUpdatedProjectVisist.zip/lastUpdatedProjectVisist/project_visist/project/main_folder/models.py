from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func

class User(db.Model, UserMixin):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key = True)
    username = db.Column(db.String(30), unique=True, nullable = False)
    password = db.Column(db.String(300), nullable=False)
    date_created = db.Column(db.DateTime(timezone=True), default=func.now())
    dlist = db.relationship('List', cascade='all, delete-orphan', backref='list')

class List(db.Model):
    __tablename__ = 'list'
    list_id = db.Column(db.Integer, primary_key=True)
    list_name = db.Column(db.String(30), nullable = False)
    description = db.Column(db.String(512), nullable = False)
    user = db.Column(db.String, db.ForeignKey('user.username'), nullable=False)
    date_created = db.Column(db.DateTime(timezone=True), default=func.now())
    last_updated = db.Column(db.DateTime(timezone=True), default=func.now())
    dcard = db.relationship('Card', cascade='all, delete-orphan', backref='card')


class Card(db.Model):
    __tablename__ = 'card'
    card_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(512), nullable = False)
    content = db.Column(db.String(512), nullable = False)
    deadline = db.Column(db.String(512))
    is_completed_flag = db.Column(db.Boolean, default = False)
    clist = db.Column(db.String, db.ForeignKey('list.list_name'), nullable = False)